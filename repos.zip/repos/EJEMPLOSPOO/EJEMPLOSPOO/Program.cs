﻿using System;

namespace EJEMPLOSPOO
{
    class Program
    {
        static void Main(String[] args)
        {
            Circulo miCirculo = new Circulo();

            Console.WriteLine(miCirculo.calculoArea(5));

            Circulo miCirculo2 = new Circulo();

            Console.WriteLine(miCirculo2.calculoArea(10));

            Console.WriteLine("--------Convresor Euro Peso---------");
            ConversorEuroPeso obj = new ConversorEuroPeso();

            obj.cambiarEuroValor(1.45);

            Console.WriteLine(obj.convierte(50));

            Console.WriteLine("--------Ejemplo Coche---------");
            Coche coche1 = new Coche(); // Crear objeto/instancia de tipo coche
            //Dar un estado inicial a el coche

            Coche coche2 = new Coche();
            Console.WriteLine($"numero de ruedas: {coche1.getInfoCoche()}");

            Coche coche3 = new Coche(4500.5, 52.5);
            Console.WriteLine($"numero de ruedas: {coche3.getInfoCoche()}");

            Console.WriteLine("--------Ejemplo Coche extras---------");
            coche3.setExtras(true, "Piel de becerro");
            Console.WriteLine(coche3.getExtras());
        }
    }

    class Coche
    {
        public Coche()
        {
            ruedas = 4;
            largo = 2300.5;
            ancho = 0.800;
        } 
        public Coche(double largoCoche, double anchoCoche)
        {
            ruedas = 4;
            largo = largoCoche;
            ancho = anchoCoche;
        }

        public String getInfoCoche()
        {
            return "Informacion del coche:" + ruedas + ", largo: " + largo + ", ancho: " + ancho;
        }

        public void setExtras(bool climatizador, String tapiceria)
        {
            this.climatizador = climatizador;
            this.tapiceria = tapiceria;
        }

        public String getExtras()
        {
            return "Extras del coche: \n" + "Tapiceria: " + tapiceria + ", Climatizador: " + climatizador;
        }

        private int ruedas;
        private double largo;
        private double ancho;
        private bool climatizador;
        private String tapiceria;
    }

    class Circulo
    {
        const double pi = 3.1416;

        public double calculoArea(int radio)
        {
            return pi * radio * radio;
        }
    }

    class ConversorEuroPeso
    {
        private double euro = 1.22;

        public double convierte(double cantidad)
        {
            return cantidad * euro;
        }

        public void cambiarEuroValor(double nuevoValor)
        {
            if(nuevoValor <= 0)
            {
                euro = 1.25;
            } else
            {
                euro = nuevoValor;
            }
        }
    }
}