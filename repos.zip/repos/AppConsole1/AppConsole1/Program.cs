﻿
using System;
using System.Linq.Expressions;

namespace AppConsole1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("------------Ejemplo de LINQ------------");
            //Especificar la funte de datos
            int[] scores = { 20, 40, 60, 80, 100, 120 };

            //Definir el Query
            IEnumerable<int> scoreQuery = 
                from score in scores
                where score > 40
                select score;

            // Ejecutar el Query
            foreach (int i in scoreQuery)
            {
                Console.WriteLine($"{i} ");
            }

            Console.WriteLine("---------------Concatenacion----------------");    

            int edad = 24;
            edad += 8;

            ////Console.WriteLine("Tienes una edad de " + ++edad + "años");
            Console.WriteLine($"Tienes una edad de {edad} años");
            Console.WriteLine("-------------Multiple declaracion------------------");

            int edadpersona1;
            int edadpersona2;
            int edadpersona3;
            int edadpersona4;

            edadpersona1 = edadpersona2 = edadpersona3 = edadpersona4 = 24;
            Console.WriteLine(edadpersona4);

            Console.WriteLine("-------------Declaracion implicita------------------");

            // Declaracion implicita de variables, se debe respetar el tipo
            var edadPersona = 27;
            var nombrePersona = "Mauricio";

            Console.WriteLine(edadPersona);
            Console.WriteLine(nombrePersona);

            Console.WriteLine("--------------Conversion Emplicita-----------------");

            // Conversion de tipos
            double temperatura = 24.5;
            int temperaturaMexico;

            //Conversion explicita
            //Casting

            //No redondea, omite los decimales
            temperaturaMexico = (int) temperatura;
            Console.WriteLine(temperaturaMexico);


            Console.WriteLine("-------------Conversion Implicita------------------");

            //Conversion implicita
            int habitantesCiudad = 10000000;
            long habitantesCiudad2018 = habitantesCiudad;

            float pesoMaterial = 5.78F;
            double pesoMaterialPrec = pesoMaterial;

            Console.WriteLine(pesoMaterialPrec);
            Console.WriteLine(habitantesCiudad2018);

            Console.WriteLine("-------------Conversiones de tipo no compatibles ------------------");

            Console.WriteLine("Introduce el primer numero");
            int num1 = int.Parse(Console.ReadLine()); //Por defecto ReadLine devuelve un String

            Console.WriteLine("Introduce el segundo numero");
            int num2 = int.Parse(Console.ReadLine());

            Console.WriteLine($"El resultado es  {num1 + num2}");

            Console.WriteLine("------------- Constantes Area de un circulo ------------------");

            const double PI = 3.1416;

            Console.WriteLine("Introduce la medida del radio");
            double radio = double.Parse(Console.ReadLine());

            //double area = radio * radio * PI;
            double area = Math.Pow(radio, 2) * PI;
            Console.WriteLine($"El area del circulo es {area}");
        }
    }
}