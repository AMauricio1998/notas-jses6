﻿using System;

namespace LANZAMIENTODEEXCEPCIONES
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce un numero de mes");
            int numeroMes = int.Parse(Console.ReadLine());

            try
            {
                Console.WriteLine(MesDelAño(numeroMes));    
            } catch(Exception ex) 
            {
                Console.WriteLine("Mensaje de la excepcion" + ex.Message);
            }

            Console.WriteLine("Aqui continuaria el resto del programa");
        }

        public static string MesDelAño(int mes)
        {
            switch (mes) 
            {
                case 1:
                    return "Enero";
                case 2:
                    return "Febrero";
                case 3:
                    return "Marzo";
                case 4:
                    return "Abril";
                case 5:
                    return "Mayo";
                case 6:
                    return "Junio";
                case 7:
                    return "Julio";
                case 8:
                    return "Agosto";
                case 9:
                    return "Septiembre";
                case 10:
                    return "Octubre";
                case 11:
                    return "Noviembre";
                case 12:
                    return "Diciembre";

                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}