﻿using System;
using static System.Math;
using static System.Console;

namespace ConceptosPOO
{
    class Program
    {
        static void Main(string[] args)
        {
            realizarTarea();

            double raiz = Sqrt(9);

            double potencia = Pow(3, 4);
            WriteLine(potencia);

            var miVariable = new { nombre = "Mauricio", edad = 18 };
            Console.WriteLine($"{miVariable.nombre} {miVariable.edad}");

            var miOtraVariable = new { nombre = "ana", edad = 25 };
        }

        static void realizarTarea()
        {
            Punto origen = new Punto();

            Punto destino = new Punto(128, 50);

            double distancia = origen.DistanciaHasta(destino);

            Console.WriteLine($"La distancia entre los puntos es de {distancia}");

            Console.WriteLine($"Numero de objetos creados {Punto.ContadorDeObjetos()}");
        }
    }
}