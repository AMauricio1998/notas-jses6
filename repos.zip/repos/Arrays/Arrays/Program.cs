﻿using System;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] edades;
            edades = new int[4];

            edades[0] = 5;
            edades[1] = 51;
            edades[2] = 52;
            edades[3] = 53;
            int[] numeros = { 0, 1, 2, 3, 4 };

            //Array implicito 
            //var datos = new[] { "Mau", "Reyes", 52};

            var valores = new[] { 15, 12, 20, 50.24 }; //todos a double

            //Array de objetos
            Empleados Ana = new Empleados("Ana", 21);

            Empleados[] arrayEmpleados = new Empleados[2]; //Indica que es un array de dos elementos

            arrayEmpleados[0] = new Empleados("Mau", 24);

            arrayEmpleados[1] = Ana;

            // Array de tipos o clases anonimas 
            var personas = new[]
            {
                new {nombre = "juan", edad = 60},
                new {nombre = "pedro", edad = 40},
                new {nombre = "ariana", edad = 23}
            };
            
            for (int i = 0; i <= personas.Length; i++) {
                Console.WriteLine(valores[i]);
            }

            for(int i = 0; i < arrayEmpleados.Length; i++)
            {
                Console.WriteLine(arrayEmpleados[i].getInfo());
            }

            foreach(Empleados empleado in arrayEmpleados)
            {
                Console.WriteLine(empleado.getInfo());
            }

            foreach(var persona in personas)
            {
                Console.WriteLine(persona);
            }

            int[] numbers = new int[4];
            numbers[0] = 0;
            numbers[1] = 1;
            numbers[2] = 2;
            numbers[3] = 3;

            ProcesaDatos(numbers);

            foreach(int i in numbers)
            {
                Console.WriteLine(i);
            }

            int[] elementos = LeerDatos();

            foreach(int elemento in elementos)
            {
                Console.WriteLine(elemento);
            }
        }

        static void ProcesaDatos(int[] datos)
        {
            for(int i = 0; i < 4; i++)
            {
                datos[i] += 10;
            }
        }

        static int[] LeerDatos()
        {
            Console.WriteLine("Cunatos elementos quieres que tenga el array");

            string respuesta = Console.ReadLine();
            int numElementos = int.Parse(respuesta);
            int[] datos = new int[numElementos];

            for (int i = 0; i < numElementos; i++)
            {
                Console.WriteLine($"Introduce el dato para la posicion {i}");
                int datosElemento = int.Parse(Console.ReadLine());
                datos[i] = datosElemento;
            }
            return datos;
        }
    }

    class Empleados
    {
        public Empleados(String nombre, int edad)
        {
            this.nombre = nombre;
            this.edad = edad;   
        }

        public String getInfo()
        {
            return "Nombre del emplado: " + nombre + " Edad: " + edad;
        }

        private String nombre;
        private int edad;
    }
}