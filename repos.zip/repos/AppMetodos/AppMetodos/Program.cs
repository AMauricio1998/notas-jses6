﻿namespace Practica_Metodos;

class Program
{
    int numero1 = 5;
    int numero2 = 7;

    static void Main(string[] args)
    {
        mensajeEnPantalla();
        Producto();
    }

    private static int Producto()
    {
        return 1 + 1;
    }

    static void mensajeEnPantalla()
    {
        Console.WriteLine("Mensaje desde el metodo mensajeEnPantalla");
        Suma(4, 5);
        Console.WriteLine(Multiplicacion(5, 5));
    }

    static void Suma(int x, int y)
    {
        int resultado = x + y;
        Console.WriteLine($"La suma de los numero es {resultado}");
    }

    static double Multiplicacion(double x, int y)
    {
        double resultado = x * y;
        return resultado;
    }

    static int resta(int x, int y) => x + y;

    static int resta(int x1, int y2, int z3) => x1 + y2; 
}