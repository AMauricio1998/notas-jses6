﻿using System;

namespace Bucle_While
{
    class Prograam
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("¿Desea entrar en el bucle while?");
            //string respuesta = Console.ReadLine();

            //while(respuesta != "no")
            //{
            //    Console.WriteLine("Estas dentro del bucle");
            //    Console.WriteLine("Introduce un nombre porfavor");

            //    string nombre = Console.ReadLine();   

            //    Console.WriteLine($"Saldra del blucle {nombre} cunado la respuesta sea 'no'");

            //    Console.WriteLine("Deseas repetir el bucle otra vez");
            //    respuesta = Console.ReadLine();
            //}

            //Console.WriteLine("Saliste del bucle");

            Random numero = new Random();
            int numeroAleatorio = numero.Next(0, 100);
            int contador = 0;

            Console.WriteLine("Intenta adivinar el numero generado");
            int numeroEntrada = Int32.Parse(Console.ReadLine());

            while(numeroAleatorio != numeroEntrada)
            {
                contador ++;

                if(numeroAleatorio > numeroEntrada)
                    Console.WriteLine("Es mayor");
                else
                    Console.WriteLine("Es menor");

                Console.WriteLine("Intentalo de nuevo");
                numeroEntrada = Int32.Parse(Console.ReadLine());
            }

            Console.WriteLine("Felicidades adivinaste el numero");

            //DO WHILE
            int z = 10;
            do
            {
                Console.WriteLine("IMpresion" + z);

                z++;
            } while (z < 10);
        }
    }
}