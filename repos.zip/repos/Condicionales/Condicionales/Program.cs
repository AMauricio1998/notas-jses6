﻿using System;

namespace Condicionales
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Introduce la calificacion del primer parcial ");
            float parcial1 = Int32.Parse(Console.ReadLine());
            
            Console.WriteLine("Introduce la calificacion del segundo parcial ");
            float parcial2 = Int32.Parse(Console.ReadLine());
            
            Console.WriteLine("Introduce la calificacion del tercero parcial ");
            float parcial3 = Int32.Parse(Console.ReadLine());

            if (parcial1 >= 5 || parcial2 >= 5 || parcial3 >= 5)
                Console.WriteLine($"La nota media es {(parcial1 + parcial2 + parcial3) / 3}");
            else
                Console.WriteLine("Vuelve en Agosto");

            //--------------------------------------------------------------------------

            bool haceFrio = false;
            int numero1 = 50;
            int numero2 = 80;
            int numero3 = 100;

            Console.WriteLine("Vamos a evaluar si cumples la edad para manejar");
            Console.WriteLine("Introduce tu edad");
            int tuEdad = Int32.Parse(Console.ReadLine());

            if(tuEdad >= 18)
            {
                Console.WriteLine("Tienes carnet(SI/NO)?");
                string carnet = Console.ReadLine();

                //int compara = String.Compare(carnet, "si", true);// returna 0 o 1

                if(carnet == "SI")
                    Console.WriteLine("Si puedes conducir");
                else
                    Console.WriteLine("No puedes conducir");
            } else 
            {
                Console.WriteLine("No puedes conducir");
            }

            Console.WriteLine("Introduce tu edad");
            int edad = int.Parse(Console.ReadLine());
            
            if (edad >= 18)
            {
                Console.WriteLine("Eres mayor de edad");
            } else
            {
                Console.WriteLine("No eres mayor de edad");
            }


            if (numero1 == numero3)
            {
                Console.WriteLine("Son igulaes");
            } else
            {
                Console.WriteLine("No son igulaes");
            }


            if (!haceFrio)
            {
                Console.WriteLine("No hace frio");
            } else
            {
                Console.WriteLine("Hace frio");
            }


        }
    }
}