﻿using System;

namespace Excepciones
{
    class Program
    {
        static void Main(string[] args)
        {
            Random numero = new Random();
            int numeroAleatorio = numero.Next(0, 100);
            int minumero;
            int contador = 0;

                Console.WriteLine("Introduce un numero entre el 1 y 100");

            do
            {
                contador++;

                try
                {
                    minumero = int.Parse(Console.ReadLine());
                }
                catch (Exception ex) when (ex.GetType() != typeof(FormatException))
                {
                    Console.WriteLine("Ocurrio un error, se tomo como n° introducido el 0");
                    minumero = 0;
                } 
                catch(FormatException ex)
                {
                    Console.WriteLine("Has introducido texto");
                    minumero = 0;
                }

                if (minumero > numeroAleatorio) Console.WriteLine("El numero es mas bajo");
                if (minumero < numeroAleatorio) Console.WriteLine("El numero es mas alto");

            } while (minumero != numeroAleatorio);
            Console.WriteLine($"Has necesitado {contador} intentos");
            Console.WriteLine("A partir de esta linea de codigo le programa continuara");
        }
    }
}